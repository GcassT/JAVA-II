
package Edu.cuc.figuras;

import java.util.Objects;


public abstract class Poligono {
    //1. ATRIBUTOS 
    protected int numeroDeLados;
    protected String color;
    
    //2. CONSTRUCTORES

    public Poligono(int numeroDeLados) {
        this.numeroDeLados = numeroDeLados;
    }

    public Poligono(int numeroDeLados, String color) {
        this.numeroDeLados = numeroDeLados;
        this.color = color;
    }
     //3.GETTERS Y SETTERS

    public int getNumeroDeLados() {
        return numeroDeLados;
    }

    public void setNumeroDeLados(int numeroDeLados) {
        this.numeroDeLados = numeroDeLados;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }
    
    //4. TOSTRING
      //Número de lados 

    @Override
    public String toString() {
        return "Poligono{" + "numeroDeLados=" + numeroDeLados + ", color=" + color + '}';
    }
   
    //5.EQUALS

    
    
    //6. MÉTODOS PROPIOS DE LA CLASE
   
    public abstract double calcularArea ();
      


    public abstract double calcularPerimetro();
    
    
    
    
    
    
    
}