
package Edu.cuc.figuras;


public class Rectangulo extends Poligono {
 //1.ATRIBUTOS PRPIOS DE LA SUBCLASE
  protected double base;
  protected double altura;  
    
    
    
//2. CREAR CONSTRUCTOR OBLIGATORIO
    public Rectangulo(double base, double altura) {
        super(4);
        this.base = base;
        this.altura = altura;
    }
    
//3.GETTERS Y SETTER

    public double getBase() {
        return base;
    }

    public void setBase(double base) {
        this.base = base;
    }

    public double getAltura() {
        return altura;
    }

    public void setAltura(double altura) {
        this.altura = altura;
    }
    
    
    

    
//4. SOBREESCRIBIR MÉTODO ABSTRACTO OBLIGATORIO

    @Override
    public double calcularArea() {
        return this.base * this.altura;
    }

    @Override
    public double calcularPerimetro() {
       return (this.base*2) + (this.altura*2);
     }
    
    
    
    
    
    
}
