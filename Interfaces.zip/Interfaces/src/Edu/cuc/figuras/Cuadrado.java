
package Edu.cuc.figuras;


public class Cuadrado extends Rectangulo {
 //1. ATRIBUTOS PROPIOS DE LA SUBCLASE
   protected double lado;
 
 //2. CONSTRUCTORES 

    public Cuadrado(double lado) {
        super(lado, lado);
        this.lado = lado;
    }
 //3. GETTERS Y SETTERS

    public double getLado() {
        return lado;
    }

    public void setLado(double lado) {
        this.lado = lado;
    }
    
 //4.TOSTRING SOBREESCRITURA

    @Override
    public String toString() {
        return "Cuadrado{" + "lado=" + lado + '}';
    }
    
    
    
    
 //5.SOBREESCRIBIR MÉTODOS PARA USAR

    @Override
    public double calcularPerimetro() {
        return this.lado * 4;
    }

    @Override
    public double calcularArea() {
        return super.calcularArea(); //To change body of generated methods, choose Tools | Templates.
    }
  
    
    
    
}
