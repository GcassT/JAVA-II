
package Edu.cuc.figuras;


public class pruebaFiguras {

    
    public static void main(String[] args) {
        Rectangulo rectangulo01 = new Rectangulo(20,10);
        Cuadrado cuadrado01 = new Cuadrado(15);
        System.out.println("El número de lados del rectangulo es: " + rectangulo01.getNumeroDeLados());
                            //RECTÁNGULO
        //PUREBA ÁREA
        System.out.println("El área del rectángulo es: " + rectangulo01.calcularArea());
        //PRUEBA PERIMETRO
         System.out.println("El perimetro del rectángulo es: " + rectangulo01.calcularPerimetro());
                           //CUADRADO
        //PRUEBA ÁREA
        System.out.println("Cuadrado 1: " + cuadrado01);
        System.out.println("El área del cuadrado es: " + cuadrado01.calcularPerimetro());
    }
    
}
