
package edu.cuc.cuentaAhorros;

import java.util.Objects;


public class Cuenta {
    //1.ATRIBUTOS
      private int numeroCuenta;
      private String titularCuenta;
      private double saldoCuenta = 0;
      
    //2. CONSTRUCTORES 

    public Cuenta(int numeroCuenta, String titularCuenta) {
        this.numeroCuenta = numeroCuenta;
        this.titularCuenta = titularCuenta;
    }

    //3. GETTERS 

    public int getNumeroCuenta() {
        return numeroCuenta;
    }

    public String getTitularCuenta() {
        return titularCuenta;
    }

    public double getSaldoCuenta() {
        return saldoCuenta;
    }
    
    //4. SETTERS

    public void setNumeroCuenta(int numeroCuenta) {
        this.numeroCuenta = numeroCuenta;
    }

    public void setTitularCuenta(String titularCuenta) {
        this.titularCuenta = titularCuenta;
    }
    
    //5. TOSTRING

    @Override
    public String toString() {
        return "Cuenta{" + "numeroCuenta=" + numeroCuenta + ", titularCuenta=" + titularCuenta + ", saldoCuenta=" + saldoCuenta + '}';
    }
    
    //6. EQUALS
    @Override
    public int hashCode() {
        int hash = 7;
        hash = 11 * hash + this.numeroCuenta;
        hash = 11 * hash + Objects.hashCode(this.titularCuenta);
        hash = 11 * hash + (int) (Double.doubleToLongBits(this.saldoCuenta) ^ (Double.doubleToLongBits(this.saldoCuenta) >>> 32));
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Cuenta other = (Cuenta) obj;
        if (this.numeroCuenta != other.numeroCuenta) {
            return false;
        }
        return true;
    }
   
    
    //7. MÉTODOS PROPIOS DE LA CLASE
        //CONSIGNAR
    public void consignar (double montoAConsignar){
        if (montoAConsignar > 0) {
            //INCREMENTAR SALDO
            this.saldoCuenta += saldoCuenta;
            
        }
        else {
        
        }
        
    }

    
    
}
