
package edu.cuc.cuentaAhorros;


public class PruebaCuenta {

    
    public static void main(String[] args) {
        //CREAR LAS CUENTAS
        Cuenta cuentaAhorros01 = new Cuenta (123, "gian");
        Cuenta cuentaAhorros02 = new Cuenta (345, "luis");
        
        System.out.println("Cuenta 1: "+cuentaAhorros01.getTitularCuenta());
        System.out.println("Cuenta 2: "+cuentaAhorros02.getTitularCuenta());
        
        //MÉTODO CONSIGNAR
        cuentaAhorros01.consignar(234.000);
        cuentaAhorros02.consignar(120.000);
        System.out.println("Cuenta 1: "+cuentaAhorros01);
        System.out.println("Cuenta 2: "+cuentaAhorros02);
        
        
    }
    
}
