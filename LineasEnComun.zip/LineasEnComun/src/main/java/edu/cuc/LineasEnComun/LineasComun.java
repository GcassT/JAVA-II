/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package edu.cuc.LineasEnComun;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author Gian Castro
 */
public class LineasComun {
  //ATRIBUTOS 
private ArrayList<String> listaDatosComunes = new ArrayList();
private File archivo01;
private File archivo02;

//CONSTRUCTORES

    public LineasComun(File archivo01, File archivo02) {
        this.archivo01 = archivo01;
        this.archivo02 = archivo02;
    }

//MÉTODOS PROPIOS DE LA CLASE
public void datosComunes (File archivo01, File archivo02) throws FileNotFoundException, IOException{
//OBTENEMOS LOS DAOTS DEL ARCHIVO 1 PARA ALMACENARLOS
//ARCHIVO 1
int contadorDatos01 = 0;
String [] datos01 = new String [contadorDatos01];
Scanner scanner01 = new Scanner(archivo01);

while (scanner01.hasNext()){
contadorDatos01++;

    for (int i = 0; i < contadorDatos01; i++) {
        datos01[i] = scanner01.next();
    }

}
 //ARCHIVO 2 
int contadorDatos02 = 0;
String [] datos02 = new String [contadorDatos02];
Scanner scanner02 = new Scanner(archivo02);

while (scanner02.hasNext()){
contadorDatos02++;

    for (int i = 0; i < contadorDatos02; i++) {
        datos02[i] = scanner02.next();
    }

}
//COMPARAMOS LOS DATOS DE AMBOS ARCHIVOS Y AÑADIMOS LOS COMUNES A UN ARRAYLIST
for (int i = 0; i < datos01.length; i++) {
        for (int j = 0; j < datos02.length; j++) {
       if (datos01[i].equalsIgnoreCase(datos02[j])) {
        listaDatosComunes.add(datos01[i]);
        
    }
        
    }
        
    }

//DEVOLVEMOS UN NUEVO ARCHIVO CON LOS DATOS COMUNES

File resultado = new File ("archivoComunes.txt");
resultado.createNewFile();
FileWriter writer = null;
writer.write(listaDatosComunes+"\n");
writer.close();
    


}




}
