/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package edu.cuc.LineasEnComun;

import java.io.File;

import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Gian Castro
 */
public class pruebaDatosComunes {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
//PREPARAMOS EL ARCHIVO
      File archivo01 = new File ("archivo01.txt");
      File archivo02 = new File ("archivo02.txt");
//CREAMOS EL ARCHIVO
try {
archivo01.createNewFile();
archivo02.createNewFile();
    System.out.println("Archivos creados exitosamente!");

}catch (IOException ex){
System.out.println(ex.getMessage());
     Logger.getLogger(pruebaDatosComunes.class.getName()).log(Level.SEVERE, null, ex);

}
//CREAMOS EL OBJETO LISTA COMUNES Y COMPARAMOS LOS ARCHIVOS
LineasComun comparador01 = new LineasComun(archivo01, archivo02);
try{
comparador01.datosComunes(archivo01, archivo02);
    System.out.println("Datos comparados exitosamente!");

}catch(IOException ex){
    System.out.println(ex.getMessage());
     Logger.getLogger(pruebaDatosComunes.class.getName()).log(Level.SEVERE, null, ex);
}







    }
    
}
