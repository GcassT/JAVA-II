/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package edu.cuc.contadorDeLineas;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

/**
 *
 * @author Gian Castro
 */
public class ContadorLineas {
    //ATRIBUTOS DE LA CLASE 
 private File archivo01;

   //CONSTRUCTOR

    public ContadorLineas(File archivo01) {
        this.archivo01 = archivo01;
    }
 //MÉTODO PROPIO DE LA CLASE
public int contarLineas() throws FileNotFoundException{
//DEFINIMOS SCANNER PARA CAPTURAR LOS DATOS DEL ARCHIVO A LEER
Scanner scanner = new Scanner (archivo01);

//SE INICIALIZA LA VARIABLE CONTADOR EN 0
int contadorLineas = 0;

//SE INICIA LA LECTURA DE DATOS DENTRO DEL ARCHIVO CON WHILE
while (scanner.hasNextLine()){
  scanner.nextLine(); //PARA LEER LOS DATOS
  contadorLineas++; //PARA CONTAR PARA LINEA ENCONTRADA 
}
//CERRAMOS EL SCANNER
scanner.close();

//DEVOLVEMOS EL RESULTADO DEL MÉTODO
return contadorLineas;

}
  
}
