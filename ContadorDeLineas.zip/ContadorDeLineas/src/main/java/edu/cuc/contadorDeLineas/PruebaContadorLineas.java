/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package edu.cuc.contadorDeLineas;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Gian Castro
 */
public class PruebaContadorLineas {

    public static void main(String[] args) {
    //CREAMOS EL NUEVO ARCHIVO A LEER
    File archivo01 = new File ("archivoEjercicio01.txt");   
    try {
    archivo01.createNewFile();
        System.out.println("Archivo Creado Exitosamente.");

     } catch (IOException ex){
           System.out.println(ex.getMessage());
            Logger.getLogger(PruebaContadorLineas.class.getName()).log(Level.SEVERE, null, ex);
    }


    //CREAMOS EL OBJETO CONTADOR DE LINEAS DE LA CLASE CONTADORLINEAS E INDICAMOS QUE ARCHIVO CONTAR
    ContadorLineas conteo01 = new ContadorLineas(archivo01);
    
   //INICIAMOS EL CONTEO DE LÍNEAS DENTRO DEL TRY CATCH
   try{
      //INVOCAMOS EL MÉTODO CONTAR LÍNEAS
      int respuesta01 = conteo01.contarLineas();

      //MOSTRAMOS EL RESULTADO
       System.out.println("El número de líneas del archivo es: "+respuesta01);


    } catch (FileNotFoundException ex) {
    System.out.println(ex.getMessage());
     Logger.getLogger(PruebaContadorLineas.class.getName()).log(Level.SEVERE, null, ex);

    }

    }
    
}
