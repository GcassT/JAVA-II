/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package edu.cuc.PalabrasLetras;

import java.io.File;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Gian Castro
 */
public class pruebaOrganizarPalabras {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       //CREAMOS EL OBJETO ARCHIVO A LEER 
    File archivo01 = new File ("archivoEjercicio04.txt");
    try { 
    archivo01.createNewFile();
        System.out.println("Archivo creado exitosamente!");
     } catch (IOException ex){ 
            System.out.println(ex.getMessage());
            Logger.getLogger(pruebaOrganizarPalabras.class.getName()).log(Level.SEVERE, null, ex);
     }
 //CREAMOS EL OBJETO PARA ORGANIZAR
 OrganizarPalabras organizar01 = new OrganizarPalabras (archivo01);

        try {
            organizar01.organizarPalabras();
            System.out.println("Palabras organizadas en archivos!");

    } catch (IOException ex){
            System.out.println(ex.getMessage());
            Logger.getLogger(pruebaOrganizarPalabras.class.getName()).log(Level.SEVERE, null, ex);
}
}
    
}
