/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package edu.cuc.PalabrasLetras;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

/**
 *
 * @author Gian Castro
 */
public class OrganizarPalabras {
    //ATRIBUTOS
private File archivo01; 

//CONSTRUCTORES

    public OrganizarPalabras(File archivo0) {
        this.archivo01 = archivo0;
    }

//MÉTODOS PROPIOS DE LA CLASE
public void organizarPalabras() throws FileNotFoundException, IOException{
char letras[] = {'a','b','c','d','e','f','g','h','i','j','k','l','m','n','o',
                  'p','q','r','s','t','u','v','w','x','y','z'};

Scanner scanner = new Scanner (archivo01);

while (scanner.hasNext()){
String palabra = scanner.next();
char [] palabraDividida = palabra.toCharArray();
    for (int i = 0; i < letras.length; i++) {
        if (palabraDividida[0] == letras[i]) {
            File resultado = new File (" "+palabraDividida[0]+".txt");
            resultado.createNewFile();
            FileWriter writer = null;
            writer.write(palabra + " ");
            writer.close();
        }
        
    }
}


}



}
