/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package edu.cuc.Guiatxt;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Gian Castro
 */
public class Lectura {
    public static void main(String[] args) {
        try{ 
        //CREAMOS EL ARCHIVO TXT PARA SER LEÍDO NUEVAMENTE
        File archivoLectura01 = new File ("ArchivoNúmeroLíneas.txt");
        Scanner scanner  = new Scanner (archivoLectura01);
        //LECTURA DEL ARCHIVO 
        while (scanner.hasNextLine()){ 
            System.out.println("Línea: "+scanner.nextLine());

         }
        //CIERRE DEL SCANNER
        scanner.close();
            System.out.println("Fin del programa!");
         } catch (FileNotFoundException ex){ 
            System.out.println(ex.getMessage());
            Logger.getLogger(Lectura.class.getName()).log(Level.SEVERE, null, ex);
        }


    }
    




}
