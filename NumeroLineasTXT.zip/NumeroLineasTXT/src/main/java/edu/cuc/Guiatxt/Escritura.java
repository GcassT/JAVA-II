/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package edu.cuc.Guiatxt;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Gian Castro
 */
public class Escritura {
    public static void main(String[] args) {
       FileWriter writer = null;
    //SE COLOCA EL CÓDIGO A EJECUTAR DENTRO DEL TRY CATCH PARA CUBRIR ERRORES
       try {
      //CREAMOS EL ARCHIVO NÚMERO DE LINEAS (SI YA EXISTE EL PROGRAMA TRABAJA SOBRE EL EXISTENTE)
       File archivo01Escritura  = new File ("ArchivoNúmeroLíneas.txt");

            //SE UTILIZA EL WRITTER COMO UN SCANNER PARA ESCRIBIR DENTRO DEL ARCHIVO
            writer = new FileWriter (archivo01Escritura, true);
            writer.write("Esta es la primera línea en el archivo.\n");
            writer.write("Segunda línea.\n");
            writer.write("Final.");
           System.out.println("Programa finalizado!");


        } catch (IOException ex){
         Logger.getLogger(Escritura.class.getName()).log(Level.SEVERE, null, ex);

       } finally {
        try {
         writer.close();

       } catch (IOException ex){
        Logger.getLogger(Escritura.class.getName()).log(Level.SEVERE, null, ex);
          }

       }



                                                
    }
}
