
package edu.cuc.Guiatxt;

import java.io.File;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Gian Castro
 */
public class Archivo {
    public static void main(String[] args) {      
        //CREAR ARCHIVO DE TEXTO 
        File archivo01 = new File ("ArchivoNúmeroLíneas.txt");
        System.out.println("Existe el archivo?: " +archivo01.exists());

        //TRY CATCH PARA LOS ERRORES DURANTE LA EJECUCIÓN 
     try {
       archivo01.createNewFile();
         System.out.println("Archivo creado exitosamente!");

      } catch (IOException ex) { 
           System.out.println(ex.getMessage());
            Logger.getLogger(Archivo.class.getName()).log(Level.SEVERE, null, ex);

       }
    }

    





}
