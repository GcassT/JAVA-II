
package edu.cuc.demoSerializacion;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Gcastro21
 */
public class Escritura {

    public static void main(String[] args) {
        String cadena01 = "Primera cadena de prueba";
        String cadena02 = "Segunda cadena de prueba";
        String cadena03 = "Fin del archivo";
        
        File archivo01 = new File ("archivoSalida.obj");
        try {//CREAMOS EL ARCHIVO DE FLUJO
            FileOutputStream flujoSalida = new FileOutputStream(archivo01);
            //CREAMOS EL OBJETO CON LA EXTENSIÓN DEL ARCHIVO QUE SERÁ SERIALIZADO
            ObjectOutputStream salida = new ObjectOutputStream(flujoSalida);
            //ESCRIBIMOS CON LA VARIABLE SALIDA
            System.out.println("Iniciando escritura!");
            salida.writeUTF(cadena01);
            salida.writeUTF("\n");
            salida.writeUTF(cadena02);
            salida.writeUTF("\n");
            salida.writeUTF(cadena03);
            //CERRAMOS EL FLUJO DE ESCRITURA
            salida.close();
            flujoSalida.close();
            System.out.println("Escritura finalizada!");
            
        } catch (FileNotFoundException ex) {
            Logger.getLogger(Escritura.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(Escritura.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
    
}
