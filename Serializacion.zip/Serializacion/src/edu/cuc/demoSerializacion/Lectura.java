
package edu.cuc.demoSerializacion;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Gcastro21
 */
public class Lectura {

    
    public static void main(String[] args) {
        File archivoEntrada = new File ("archivoSalida.obj");
        try {
            //CREAMOS EL FLUJO DE ENTRADA
            FileInputStream flujoEntrada = new FileInputStream(archivoEntrada);
            //CREAMOS EL OBJETO CON LA EXTENSIÓN DEL ARCHIVO A MODIFICAR
            ObjectInputStream entrada = new ObjectInputStream(flujoEntrada);
            //LECTURA
            String cadena = entrada.readUTF();
            //EL ARCHIVO GUARDA LA ULTIMA LECTURA Y CONTINÚA DONDE QUEDÓ
            System.out.println("Cadena leeída: "+cadena);
                System.out.println("Cadena leída 2: "+entrada.readUTF());
                System.out.println("Cadena leída 3: "+entrada.readUTF());
                
            //CREAMOS UN OBJETO PARA LEER 
            Object objetoLeido = entrada.readObject();
            //SE HACE LA CONVERSIÓN PARA QUE EL OBJETO PUEDA LEER ARRAYLIST
            ArrayList<Integer> listaLeida = (ArrayList<Integer>) objetoLeido;
            
            //CERRAR FLUJOS EN EL ORDEN OPUESTO A COMO SE CREARON
            entrada.close();
            flujoEntrada.close();
        } catch (FileNotFoundException ex) {
            Logger.getLogger(Lectura.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(Lectura.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Lectura.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
}
