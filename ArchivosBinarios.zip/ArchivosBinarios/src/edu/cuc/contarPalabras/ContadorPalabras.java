
package edu.cuc.contarPalabras;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

/**
 *
 * @author Gian Castro
 */
public class ContadorPalabras {
    //ATRIBUTO
private String archivoContarPalabras;

//CONSTRUCTOR

    public ContadorPalabras(String archivoContarPalabras) {
        this.archivoContarPalabras = archivoContarPalabras;
    }

//MÉTODO
public int numeroPalabras(String archivoContarPalabras) throws FileNotFoundException, IOException{
//CREAMOS LA CLASE PARA LEER EL ARCHIVO 
FileInputStream entrada = new FileInputStream (archivoContarPalabras);
//TAMBIÉN SE CREA EL CONTADOR DE PALABRAS
             
             int contadorPalabras = 0;
            while (entrada.available() != 0 ) {                
                int byteLeido = entrada.read();
                char caracterLeido = (char) byteLeido;
                if (caracterLeido == ' ') {
                    contadorPalabras++;
                } 

}

return contadorPalabras;

}
}
