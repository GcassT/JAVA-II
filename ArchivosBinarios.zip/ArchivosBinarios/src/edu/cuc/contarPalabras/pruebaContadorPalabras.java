
package edu.cuc.contarPalabras;

import edu.cuc.archivosBinarios.DemoLectura;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Gian Castro
 */
public class pruebaContadorPalabras {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
try {
    System.out.println("Iniciando programa!");
    ContadorPalabras contador01 = new ContadorPalabras("escribirEnArchivo.txt");
    System.out.println("El número de palabras leídas es: "+contador01.numeroPalabras("escribirEnArchivo.txt"));
    System.out.println("Programa finalizado!");


 }catch (IOException ex){
System.out.println(ex.getMessage());
 Logger.getLogger(pruebaContadorPalabras.class.getName()).log(Level.SEVERE, null, ex);

}




    }
    
}
