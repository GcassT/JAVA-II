
package edu.cuc.ImagenBPM;

import edu.cuc.archivosBinarios.DemoLectura;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;


/**
 *
 * @author Gian Castro
 */
public class ImagenBPM {
//ATRIBUTOS DE LA CLASE
    private File archivo01;
//CONSTRUCTOR

    public ImagenBPM(File archivo01) {
        this.archivo01 = archivo01;
    }

    

//MÉTODO DE LA CLASE 
public boolean imagenBPM () throws FileNotFoundException, IOException {
//INICIALIZAMOS LA CLASE PARA LEER ARCHIVOS BINARIOS
FileInputStream entrada = new FileInputStream(archivo01);

//LEEMOS EL PRIMER BYTE DEL ARCHIVO
    int primerByte = entrada.read();
    char primeraLetra = (char) primerByte;
//IMPRIMIMOS LA PRIMERA LETRA LEÍDA
System.out.println("El primer dato encontrado es: "+primeraLetra);
System.out.println("");

//REPETIMOS PARA LA SEGUNDA LETRA
int segundoByte = entrada.read();
char segundaLetra = (char) segundoByte;
//IMPRIMIMOS LA SEGUNDA LETRA
System.out.println("El segundo dato encontrado es: "+segundaLetra);

//COMPARAMOS LAS LETRAS ENCONTRADAS PARA VER SI CUMPLE LOS REQUISITOS
if (primeraLetra == 'B' && segundaLetra == 'M') {
        return true;
    } else {
return false;
}





}








    }

