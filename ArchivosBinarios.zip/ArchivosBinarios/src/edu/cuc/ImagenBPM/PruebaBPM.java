/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package edu.cuc.ImagenBPM;

import edu.cuc.archivosBinarios.DemoLectura;
import java.io.File;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Gian Castro
 */
public class PruebaBPM {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       //CREAMOS EL ARCHIVO NUEVO
     File archivo01 = new File ("imagenBPM.txt");
try{
archivo01.createNewFile();
    System.out.println("Archivo creado exitosamente!");

}catch (IOException ex){
        System.out.println(ex.getMessage());
        Logger.getLogger(PruebaBPM.class.getName()).log(Level.SEVERE, null, ex);
}

try {   
ImagenBPM nuevaImagen = new ImagenBPM(archivo01);  
boolean respuesta01 = nuevaImagen.imagenBPM();
    if (respuesta01) {
        System.out.println("El archivo es de tipo BPM");
    } else {
        System.out.println("El archivo no es de tipo BPM");
}
   

} catch (IOException ex){ 
       System.out.println(ex.getMessage());
        Logger.getLogger(PruebaBPM.class.getName()).log(Level.SEVERE, null, ex);
}



    }
    
}
