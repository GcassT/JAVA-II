package edu.cuc.almacenarEnArchivo;

import edu.cuc.archivosBinarios.DemoEscritura;
import java.io.File;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Gian Castro
 */
public class PruebaEscribirEnArchivo {

    
    public static void main(String[] args) {
      //CREAMOS EL ARCHIVO NUEVO A UTILIZAR
    File archivo01 = new File ("escribirEnArchivo.txt");
    try {
        System.out.println("programa iniciado!");
        //CREAMOS LA CLASE ESCRIBIR ARCHIVO
        EscribirEnArchivo escritura01 = new EscribirEnArchivo (archivo01);
        String resultado01 = escritura01.guardarEnArchivo();
        System.out.println(resultado01);
        System.out.println("");
        System.out.println("Programa finalizado!");
   } catch (IOException ex){
    System.out.println(ex.getMessage());
    Logger.getLogger(PruebaEscribirEnArchivo.class.getName()).log(Level.SEVERE, null, ex);
   }




    }
    
}
