/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package edu.cuc.almacenarEnArchivo;

import java.io.File;
import java.io.IOException;
import java.io.FileOutputStream;
import java.util.Scanner;

/**
 *
 * @author Gian Castro
 */
public class EscribirEnArchivo {
//ATRIBUTOS 
   private File archivo01;

//CONSTRUCTOR

    public EscribirEnArchivo(File archivo01) {
        this.archivo01 = archivo01;
    }

//MÉTODO
public String guardarEnArchivo () throws IOException {
//DECLARAMOS la cadena QUE IRÁ EN EL RETORNO
String resultado = "Texto guardado exitosamente!";

//DECLARAMOS UN SCANNER Y PEDIMOS EL TEXTO A GUARDAR EN EL ARCHIVO
Scanner scanner = new Scanner  (System.in);
    System.out.println("Por favor ingrese el texto a guardar en el archivo: ");
    String texto01 = scanner.nextLine();

//CREAMOS EL ARCHIVO DONDE SE ALMACENARÁ EL TEXTO
FileOutputStream salida = new FileOutputStream (archivo01,true);

//ALMACENAMOS LA CADEBA EN UN VECTOR DE BYTES
byte [] textoAlmacenado = texto01.getBytes();

//ESCRIBIRMOS EL VECTOR DE BYTES EN EL ARCHIVO BINARIO
salida.write(textoAlmacenado);

//CERRAMOS EL ESCRITOR
salida.close();



//RETORNAMOS EL STRING INICIAL INDICANDO QUE EL PROGRAMA SE EJECUTÓ CORRECTAMENTE
return resultado;
}





}
