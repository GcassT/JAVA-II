
package edu.cuc.numeroLineasBinario;

import edu.cuc.ImagenBPM.PruebaBPM;
import java.io.File;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Gian Castro
 */
public class pruebaContadorLienas {

    public static void main(String[] args) {
     //CREAMOS EL ARCHIVO A LEER 
    File archivo01 = new File ("contadorLienas.txt");

    //CREAMOS EL BLOQUE DE TRY CATCH Y PROBAMOS 
    try {
        archivo01.createNewFile();
        System.out.println("Programa iniciado!");
        ContadorLineas conteo01 = new ContadorLineas(archivo01);
        int resultado01 = conteo01.numeroLineas(archivo01);
        System.out.println("El número de líenas del archivo es: "+resultado01);
        System.out.println("Progama finalizado!");

    }catch (IOException ex){
        System.out.println(ex.getMessage());
        Logger.getLogger(PruebaBPM.class.getName()).log(Level.SEVERE, null, ex);    
    }



    }
    
}
