package edu.cuc.numeroLineasBinario;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

/**
 *
 * @author Gian Castro
 */
public class ContadorLineas {
    //ATRIBUTOS
private File archivo01;

    //CONSTRUCTOR

    public ContadorLineas(File archivo01) {
        this.archivo01 = archivo01;
    }

   //MÉTODOS
public int numeroLineas(File archivo01) throws FileNotFoundException, IOException {

//CREAMOS LA CLASE FILE INPUT
FileInputStream entrada = new FileInputStream(archivo01);

//DECLARAMOS EL STRING VACÍO QUE LEERA LOS DATOS
String cadena01 = "";
int numeroLineas = 0; //DECLARAMOS EL CONTADOR DE LÍNEAS
while (entrada.available() != 0){
int byteLeido = entrada.read();
char caracterLeido = (char) byteLeido;
//CONDICIONAL SI EL CARACTER LEIDO HACE SALTO DE LINEA EL CONTADOR AUMENTA
    if (caracterLeido == '\n') {
        numeroLineas = numeroLineas+1;
    } 

}
    //CERRAMOS EL LECTOR
    entrada.close();

    //RETORNAMOS EL NÚMERO DE LINEAS CONTADAS
    return numeroLineas;
}







}
