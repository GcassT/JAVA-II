
package edu.cuc.compararArchivos;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;

/**
 *
 * @author Gian Castro
 */
public class ComparadorArchivos {
    //ATRIBUTOS 
ArrayList<String> palabras01 = new ArrayList<>();
ArrayList<String> palabras02 = new ArrayList<>();
private String archivoComparar01;
private String archivoComparar02;
private String archivoSalida03;

//CONSTRUCTORES

    public ComparadorArchivos(String archivoComparar01, String archivoComparar02) {
        this.archivoComparar01 = archivoComparar01;
        this.archivoComparar02 = archivoComparar02;
    }

//MÉTODOS
public void palabrasComunes(String archivoComparar01, String archivoComparar02)
throws FileNotFoundException, IOException{
//CREAMOS LAS CLASES PARA LEER LOS ARCHIVOS
FileInputStream entradaArchivo01 = new FileInputStream(archivoComparar01);
FileInputStream entradaArchivo02 = new FileInputStream(archivoComparar02);
FileOutputStream salidaArchivo02 = new FileOutputStream(archivoSalida03);

//ARCHIVO 1
           String cadena01 = "";
            while (entradaArchivo01.available() != 0 ) {                
                int byteLeido = entradaArchivo01.read();
                char caracterLeido = (char) byteLeido;
                if (caracterLeido == ' ') {
                  cadena01 = "";
                  palabras01.add(cadena01);
                } 

              }

//ARCHIVO 2
           String cadena02 = "";
            while (entradaArchivo02.available() != 0 ) {                
                int byteLeido = entradaArchivo02.read();
                char caracterLeido = (char) byteLeido;
                if (caracterLeido == ' ') {
                  cadena02 = "";
                  palabras02.add(cadena02);
                } 

              }
    if (palabras01.equals(palabras02)) {
      File archivoSalida03 = new File ("archivoSalida03");
    }


}





}
