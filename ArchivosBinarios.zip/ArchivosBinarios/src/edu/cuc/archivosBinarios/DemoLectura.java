
package edu.cuc.archivosBinarios;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author gcastro21
 */
public class DemoLectura {
    public static void main(String[] args) {

        File archivo01 = new File ("archivoSalida.txt");
        try {
            FileInputStream entrada = new FileInputStream(archivo01);
            System.out.println("Inicializando archivo.");
            //LEE UN CARACTER
            //LEER POR CADENA
            String cadena = "";
            while (entrada.available() != 0 ) {                
                int byteLeido = entrada.read();
                char caracterLeido = (char) byteLeido;
                if (caracterLeido == ' ') {
                    System.out.println("Cadena leída: "+cadena);
                    cadena = "";
                } else {
                cadena += caracterLeido;
                }
//                System.out.println("Valor leído " + byteLeido + " :" + caracterLeido);
//                System.out.println("Lectura finalizada!");
                
            }
        } catch (FileNotFoundException ex) {
            System.out.println(ex.getMessage());
            Logger.getLogger(DemoLectura.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(DemoLectura.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
}
