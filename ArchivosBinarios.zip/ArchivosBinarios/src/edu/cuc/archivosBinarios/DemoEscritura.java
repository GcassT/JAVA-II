
package edu.cuc.archivosBinarios;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author gcastro21
 */
public class DemoEscritura {

    public static void main(String[] args) {
      File archivo01 = new File ("archivoSalida.txt");
      String cadena01 = "Netbeans.";
      String cadena02 = "Eso es una línea de prueba.";
      
        try {
            //ESCRIBIR POR CARACTERES (BYTE POR BYTE)
            System.out.println("Inicializando archivo");
            FileOutputStream salida = new FileOutputStream(archivo01);
//            salida.write('x');
//            salida.close();
//            System.out.println("Escritura terminada");
          //ESCRIBIR POR CADENA (BYTE POR BYTE)
//           char[] vectorCaracteres = cadena01.toCharArray();
//            for (int i = 0; i < vectorCaracteres.length; i++) {
//                char caracterActual = vectorCaracteres[i];
//                salida.write(caracterActual);
////                salida.write('\n');
//                
//            }
//            salida.close();
          //POR CADENAS COMPLETAS (LINEA COMPLETA)
          byte[] bytes1 = cadena01.getBytes();
          byte[] bytes2 = cadena02.getBytes();
          salida.write(bytes1);
          salida.write('\n');
          salida.write(bytes2);
          salida.close();
        } catch (FileNotFoundException ex) {
            System.out.println(ex.getMessage());
            Logger.getLogger(DemoEscritura.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
             System.out.println(ex.getMessage());
            Logger.getLogger(DemoEscritura.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
}
