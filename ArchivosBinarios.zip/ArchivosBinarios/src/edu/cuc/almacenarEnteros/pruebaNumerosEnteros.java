
package edu.cuc.almacenarEnteros;

import edu.cuc.almacenarEnArchivo.PruebaEscribirEnArchivo;
import java.io.File;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Gian Castro
 */
public class pruebaNumerosEnteros {

   
    public static void main(String[] args) {
  try{
      System.out.println("Iniciando programa!");
      NumerosEnteros enteros01 = new NumerosEnteros("ArchivoEnteros");
      enteros01.almacenarEnteros("archivoEnteros");   
      System.out.println("Programa finalizado");

    }catch (IOException ex){
    System.out.println(ex.getMessage());
    Logger.getLogger(pruebaNumerosEnteros.class.getName()).log(Level.SEVERE, null, ex);

    }







    }
    
}
