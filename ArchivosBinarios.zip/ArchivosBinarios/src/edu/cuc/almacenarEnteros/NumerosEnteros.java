
package edu.cuc.almacenarEnteros;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import javax.swing.JOptionPane;

/**
 *
 * @author Gian Castro
 */
public class NumerosEnteros {
//ATRIBUTOS
private String archivoEnteros;

//CONSTRUCTOR

    public NumerosEnteros(String archivoEnteros) {
        this.archivoEnteros = archivoEnteros;
    }

    
    

//MÉTODO
public void almacenarEnteros(String archivoEnteros) throws FileNotFoundException, IOException{
//INICIALIZAMOS LA CLASE PARA ESCRIBIR EN EL ARCHIVO

FileOutputStream salida = new FileOutputStream(archivoEnteros);

//PEDIMOS LA CANTIDAD DE NÚMEROS ENTEROS QUE EL USUARIO DESEA ESCRIBIR EN EL ARCHIVO Y
//LOS ALMACENAMOS EN UN VECTOR 
int cantidadEnteros = Integer.parseInt(JOptionPane.showInputDialog("Ingrese la cantidad de enteros a escribir: "));

String [] vectorNumeros = new String [cantidadEnteros];

    for (int i = 0; i < cantidadEnteros; i++) {
     vectorNumeros[i] = JOptionPane.showInputDialog("Ingrese el número:");   
    }
//CONVERTIMOS EL VECTOR EN UN STRING Y LO ALMACENAMOS EN UNA VARIABLE
String vectorNumerosString = Arrays.toString(vectorNumeros);

//CREAMOS UN VECTOR DE CARACTERES Y GUARDAMOS EL STRING DE  NÚMEROS DENTRO
char [] vectorNumerosFinal = vectorNumerosString.toCharArray();

//RECORREMOS EL VECTOR DE CARACTERES Y GUARDE CADA VALOR EN UNA SOLA VARIABLE
for (int i = 0; i < vectorNumerosFinal.length; i++) {
        char caracterActual = vectorNumerosFinal[i];

    //ESCRIBIMOS LA VARIABLE EN EL ARCHIVO BINARIO
    salida.write(caracterActual);
        
    }
    
    //CERRAMOS EÑ ESCRITOR
    salida.close();





}




}
