
package Edu.cuc.interfaces;


public class Fraccionario {
 //1.ATRIBUTOS PROPIOS DE LA CLASE
    protected int numerador;
    protected int denominador;
 
//2. CONSTRUCTORES CON EXCEPCIÓN

    public Fraccionario(int numerador, int denominador) throws Exception {
        this.numerador = numerador;
        if (denominador == 0) {
            //lanzar una excepcion
            throw new Exception("el denominador esta en cero!!");
        } else {
            this.denominador = denominador;
        }
    }
    
 //3. GETTERS Y SETTERS CON EXCEPCIÓN EN EL SETTER

    public int getNumerador() {
        return numerador;
    }

    public void setNumerador(int numerador) {
        this.numerador = numerador;
    }

    public int getDenominador() {
        return denominador;
    }

    public void setDenominador(int denominador) throws Exception {
        if (denominador == 0) {
            //LANZAR LA EXCEPCIÓN
            throw new Exception("el denominador esta en cero!!");
        } else {
            this.denominador = denominador;
        }
    }
 //TOSTRING
    @Override
    public String toString() {
        return "Fraccionario{" +  numerador + "/" + denominador + '}';
    }
    
 //MÉTODOS PROPIOS DE LA CLASE
    //VALOR
    public double valor(){
        return ((double)this.numerador / this.denominador);
                
    }
    
    //SUMAR
    public Fraccionario sumar (Fraccionario fraccion02) throws Exception{
    int numeradorSuma = (this.numerador *fraccion02.denominador) + 
                        (this.denominador * fraccion02.numerador);
    int denominadorSuma = this.denominador * fraccion02.denominador;
    //this.getDenominador() * fraccion02.getDenominador();
    Fraccionario fraccionSuma = new Fraccionario (numeradorSuma, denominadorSuma);
    return fraccionSuma;
    
    }
    
    //RESTAR
        public Fraccionario restar (Fraccionario fraccion02) throws Exception {
        int numeradorResta = (this.numerador *fraccion02.denominador) -
                            (this.denominador * fraccion02.numerador);
        int denominadorResta = this.denominador * fraccion02.denominador;
    //this.getDenominador() * fraccion02.getDenominador();
    Fraccionario fraccionResta = new Fraccionario (numeradorResta, denominadorResta);
    return fraccionResta;
              
        
        }
        
     //MULTIPLICAR
        public Fraccionario multiplicar (Fraccionario fraccion02) throws Exception{
        return new Fraccionario (this.numerador * fraccion02.numerador,
                                this.denominador * fraccion02.denominador);
        
        
        
        }
        
      //DIVIDIR
          public Fraccionario dividir (Fraccionario fraccion02) throws Exception{
        return new Fraccionario (this.numerador * fraccion02.numerador,
                                this.denominador * fraccion02.denominador);
        
        
        
        }
      
    
    
    
    
    
    
    
    
    
    
}
