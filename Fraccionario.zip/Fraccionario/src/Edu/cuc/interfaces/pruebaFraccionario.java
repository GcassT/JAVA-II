
package Edu.cuc.interfaces;

import java.util.logging.Level;
import java.util.logging.Logger;


public class pruebaFraccionario {

    
    public static void main(String[] args) {
        try {
            Fraccionario fraccion01 = new Fraccionario (2,0);
        } catch (Exception ex) {
            Logger.getLogger(pruebaFraccionario.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
}
