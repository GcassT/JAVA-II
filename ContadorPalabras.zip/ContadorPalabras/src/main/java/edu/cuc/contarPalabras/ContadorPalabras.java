/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package edu.cuc.contarPalabras;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

/**
 *
 * @author Gian Castro
 */
public class ContadorPalabras {
//MÉTODOS DE LA CLASE
    private File archivo01;

//CONSTRUCTOR
    public ContadorPalabras(File archvio01) {
        this.archivo01 = archvio01;
    }

//MÉTODO PROPIO DE LA CLASE
public int contarPalabras() throws FileNotFoundException{
//DEFINIMOS SCANNER PARA CAPTURAR LAS PALABRAS
Scanner scanner = new Scanner(archivo01);

//CREAMOS EL CONTADOR DE PALABRAS INICIAZILADO EN 0
int contadorPalabras = 0;
 
//SE UTILIZA WHILE PARA CONTAR CADA PALABRA ENCONTRADA EN EL ARCHIVOD EL TEXTO
while(scanner.hasNext()){
scanner.next(); //PARA LEER LOS DATOS
contadorPalabras++; //PARA AUMENTAR POR PALABRA ENCONTRADA
}
scanner.close();
return contadorPalabras;

}


}
