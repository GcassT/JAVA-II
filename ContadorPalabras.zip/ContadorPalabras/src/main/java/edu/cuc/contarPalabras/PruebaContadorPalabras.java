/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package edu.cuc.contarPalabras;

import java.io.File;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Gian Castro
 */
public class PruebaContadorPalabras {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       //CREAMOS EL OBJETO ARCHIVO
    File archivo01 = new File ("ArchivoEjercicio03.txt");

try { 
  archivo01.createNewFile();
    System.out.println("Archivo creado exitosamente!");


} catch(IOException ex){
 System.out.println(ex.getMessage());
            Logger.getLogger(PruebaContadorPalabras.class.getName()).log(Level.SEVERE, null, ex);

} 
//CREAMOS EL OBJETO CONTADOR PARA ALMACENAR EL CONTEO DE PALABRAS
ContadorPalabras conteo01 = new ContadorPalabras (archivo01);

//INICIAMOS EL CONTEO DE LINEAS DENTRO DE TRY CATCH
try {
//INVOCAMOS EL MÉTODO CONTAR DE LA CLASE CONTADOR
int respuesta01 = conteo01.contarPalabras();

    System.out.println("El número de palabras es: "+respuesta01);

}catch (IOException  ex){
System.out.println(ex.getMessage());
 Logger.getLogger(PruebaContadorPalabras.class.getName()).log(Level.SEVERE, null, ex);
}
   











    }
    
}
