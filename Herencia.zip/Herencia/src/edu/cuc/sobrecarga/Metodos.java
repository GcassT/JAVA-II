package edu.cuc.sobrecarga;

public class Metodos {

    //SUMAR ENTEROS 
    public static int sumar(int numero01, int numero02) {
        return numero01 + numero02;

    }

    //SUMAR REALES
    public static double sumar(double numero01, double numero02) {
        return numero01 + numero02;

    }
    //SUMAR VECTORES
    public static int[] sumar(int[] vector01, int[] vector02) {
        if (vector01.length == vector02.length) {
            //SUMA DE VECTORES
            int[] vectorSuma = new int[vector01.length];
            for (int i = 0; i < vector01.length; i++) {
                vectorSuma[i] = vector01[i] + vector02[i];
            }
            return vectorSuma;
            
        } else {
            //NO SE PUEDE HACER LA SUMA
            return null;
        }

    }
    //SUMA DE MATRICES
}
