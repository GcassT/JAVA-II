
package edu.cuc.sobrecarga;

import java.util.Arrays;


public class PruebaMetodos {

   
    public static void main(String[] args) {
        //PRUEBA SUMA DE ENTEROS
       int numero01 = 40;
       int numero02 = 150;
       int sumaEnteros = Metodos.sumar(numero01, numero02);
        System.out.println("La suma de los números es: "+sumaEnteros);
        
        //PRUEBA SUMA DE REALES
       double numero03 = 45.67;
       double numero04 = 234.87;
       double sumaReal = Metodos.sumar(numero03, numero04);
        System.out.println("La suma de los números es: "+sumaReal);
        
       //PRUEBA SUMA VECTORES
       int[] vector01 = {1,2,3};
       int[] vector02 = {4,5,6};
       int[] sumaVector = Metodos.sumar(vector01, vector02);
        System.out.println("La suma de los vectores es: "+Arrays.toString(sumaVector));
       
    }
    
}
