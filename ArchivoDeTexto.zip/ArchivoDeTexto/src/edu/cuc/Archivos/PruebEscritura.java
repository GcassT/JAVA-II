
package edu.cuc.Archivos;
import java.io.File;


public class PruebEscritura {
    public static void main(String[] args) {
        File miArchivo = new File ("archivodeprueba.txt");
        
    }

    
    
}
