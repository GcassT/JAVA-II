
package edu.cuc.Archivos;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;


public class PruebaLectura {
    public static void main(String[] args) {
        try {
            File miArchivo = new File("Arcvhivodeprueba.txt");
            Scanner scanner= new Scanner (miArchivo);
            
            //LECTURA
            System.out.println("Línea: "+scanner.nextLine());
            System.out.println("Línea: "+scanner.nextLine());
            //CIERRE SCANNER
            scanner.close();
            
            System.out.println("Fin del programa!");
        } catch (FileNotFoundException ex) {
            Logger.getLogger(PruebaLectura.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
